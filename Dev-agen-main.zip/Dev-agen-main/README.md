# Gen Agent - Vercel Deploy Ready

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/gen-agent-vercel)

ตัวนี้ทำมาเพื่อ Vercel โดยเฉพาะ - Deploy ง่ายสุด กดปุ่มเดียวจบ

## โครงสร้าง Vercel
- `/public/index.html` - หน้าเว็บ Agent Research Hub (วางลิงก์ + ไฟล์)
- `/api/index.py` - Backend FastAPI (Research -> Expert -> Support) - Vercel Serverless Function
- `vercel.json` - Config ให้ Vercel รู้จัก API + Static

## Deploy ขึ้น Vercel (1 นาที)

### วิธีที่ 1: กดปุ่ม Deploy (เร็วสุด)
1. Push โฟลเดอร์นี้ขึ้น GitHub
2. กดปุ่ม Deploy with Vercel ด้านบน
3. ใส่ ENV: `OPENAI_API_KEY` (ไม่ใส่ก็รัน Mock ได้)
4. Deploy -> ได้ลิงก์ `https://your-app.vercel.app` ทันที

### วิธีที่ 2: Vercel CLI
```bash
npm i -g vercel
vercel login
vercel --prod
# ใส่ ENV ตอน deploy
```

### วิธีที่ 3: ผ่านเว็บ Vercel
1. vercel.com -> Add New Project -> Import GitHub repo นี้
2. Framework Preset: Other
3. ENV: OPENAI_API_KEY=sk-xxx
4. Deploy

## หลัง Deploy จะได้
- `https://your-app.vercel.app/` - หน้าเว็บหลัก วางลิงก์ + อัพไฟล์
- `https://your-app.vercel.app/api/docs` - API Docs
- `https://your-app.vercel.app/api/research/upload` - API อัพโหลด

## ข้อดี Vercel
- ฟรี, เร็ว, ไม่ต้องจัดการ Docker
- Auto HTTPS
- Serverless - ไม่ต้องจ่ายตอนไม่มีคนใช้
- Deploy แค่ push code

## ENV ที่ต้องใส่ใน Vercel Dashboard
- `OPENAI_API_KEY` - ถ้าไม่ใส่จะรัน Mock Mode
- `AGENT_MODEL` - default gpt-4o-mini

พร้อม Deploy 100% สำหรับ Vercel
