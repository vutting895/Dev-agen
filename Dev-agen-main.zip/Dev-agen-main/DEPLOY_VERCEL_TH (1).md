# Deploy ขึ้น Vercel แบบละเอียด

## ขั้นตอน

1. แตกไฟล์ gen-agent-vercel.zip
2. Push ขึ้น GitHub:
```bash
git init
git add .
git commit -m "vercel ready"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/gen-agent-vercel.git
git push -u origin main
```

3. ไป https://vercel.com/new
4. Import GitHub repo gen-agent-vercel
5. ในหน้า Configure Project:
   - Framework Preset: Other
   - Root Directory: ./
   - Add Environment Variable: OPENAI_API_KEY = sk-xxx

6. กด Deploy -> รอ 1 นาที -> ได้ลิงก์ https://gen-agent-vercel.vercel.app

## เทส
- เปิดลิงก์ -> จะเจอหน้า Agent Research Hub
- วางลิงก์เว็บ + อัพไฟล์ -> กดเริ่มวิจัย
- คุยกับ Expert ได้เลย

จบ!
